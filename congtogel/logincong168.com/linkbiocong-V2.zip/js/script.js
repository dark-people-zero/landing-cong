document.getElementById("link-1").onclick = function () {
    window.location.href = "https://188.166.178.229:118/";
  };
  document.getElementById("link-2").onclick = function () {
    window.location.href = "https://ayocong1.com/";
  };
  document.getElementById("link-3").onclick = function () {
    window.location.href = "https://ayocong168.com/";
  };
  document.getElementById("link-4").onclick = function () {
    window.location.href = "https://ayocong168.org/";
  };
  document.getElementById("link-5").onclick = function () {
    window.location.href = "https://ayocong1.net/";
  };
  document.getElementById("link-wap").onclick = function () {
    window.location.href = "https://ayocong1.org/lite/login.php";
  };
  document.getElementById("link-bonus").onclick = function () {
    window.location.href = "http://promo01.cong168.org/";
  };
  document.getElementById("link-playstore").onclick = function () {
    window.location.href =
      "https://cong168.org/cdn/app/congtogel-v.4.7.apk";
  };
  document.getElementById("link-livechat").onclick = function () {
    window.location.href = "https://direct.lc.chat/13407159/";
  };